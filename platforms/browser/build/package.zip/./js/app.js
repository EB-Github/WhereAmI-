var app = angular.module('App', ['ngCordova']);

app.controller('appCtrl', function($scope) {
    $scope.firstName= "John";
    $scope.lastName= "Doe";
});
